import Foundation
// Написать функцию которая определяет четное число или нет!

print ("Задание №1")


let numbersArray = [1,2,3,4,5,6,7,8,9,10,11,12,13]

func evenOdd (_ num:Int) -> Bool {
    if num % 2 == 0 {
        return true
    }else{
        return false
    }
}

for i in 0 ... numbersArray.count - 1 {
    if evenOdd (numbersArray[i]) {
        print ("Число \(numbersArray[i]) четное ")
    }else{
        print ("Число \(numbersArray[i]) нечетное")
    }
}

// Написать функцию , которая проверяет, делится ли число без остатка на 3.

print ("Задание №2")

let numbersArray_2 = [1,3,6,9]

func devThree (_ num:Int) -> Bool {
    if num % 3 == 0 {
        return true
    }else{
        return false
    }
}

for i in 0 ... numbersArray_2.count - 1 {
    if devThree (numbersArray_2[i]) {
        print ("\(numbersArray_2[i]) делится на 3 без остатка ")
    }else{
        print ("\(numbersArray_2[i]) делится на 3 с остатком ")
    }
}

// Создать возрастающий массив из 100 чисел.

print ("Задание №3")

var array = [Int]()

for i in 0...100 {
    array.append(i)
}
print ("Возрастающий массив из 100 чисел : \(array)")





